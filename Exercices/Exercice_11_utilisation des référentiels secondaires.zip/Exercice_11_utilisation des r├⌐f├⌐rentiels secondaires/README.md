Cette exercice permet de ...

<!-- AUTEUR : Michel TANGUY -->
<!-- DATE : 2023 --> 
